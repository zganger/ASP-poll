﻿CREATE TABLE [dbo].[Candidates]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] TEXT NOT NULL, 
    [Count] INT NOT NULL
)
